# 当前论文的证据来源与复核边界

当前主结果提交：`28daf95e9b12270d8089246176023c66c4cf298e`。095来源固定如下；下方历史来源保留原094快照，未回写旧研究数据。

## 095新增事实来源

|键|工件|用途|
|---|---|---|
|E095_report|[outputs/095_anchored_minimal_contrast/report.md](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/report.md)|实际完成范围、主结果、阶段成本|
|E095_metrics|[outputs/095_anchored_minimal_contrast/baseline_metrics.json](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/baseline_metrics.json)|同8997混淆矩阵与指标|
|E095_paired|[outputs/095_anchored_minimal_contrast/baseline_paired.json](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/baseline_paired.json)|患者配对与区间（本包引用，不从聚合矩阵复算）|
|E095_findings|[outputs/095_anchored_minimal_contrast/baseline_findings.md](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/baseline_findings.md)|作者/来源分层、score组合、重复与无效|
|E095_transitions|[outputs/095_anchored_minimal_contrast/baseline_class_transitions.json](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/baseline_class_transitions.json)|两套三维类别转移计数|
|E095_quality|[outputs/095_anchored_minimal_contrast/candidate_cases.md](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/candidate_cases.md)|300构造及24例质量审查；E/C未执行|
|E095_review|[reviews/095_anchored_minimal_contrast/final_review.md](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/reviews/095_anchored_minimal_contrast/final_review.md)|独立子执行者的原生身份/输入/数值/费用复核|
|E095_code|[tasks/095_anchored_minimal_contrast/method095.py](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/tasks/095_anchored_minimal_contrast/method095.py)|唯一span、值引用与布尔checker实际实现|
|E095_cost|[outputs/095_anchored_minimal_contrast/cost_ledger.json](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/cost_ledger.json)|目录价/usage账本，不是实扣余额|
|E095_source_review|[outputs/095_anchored_minimal_contrast/source_review_80_summary.json](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/source_review_80_summary.json)|80例发现性原文回查，非总体因果比例|
|E095_history|[outputs/095_anchored_minimal_contrast/history_difference.md](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/history_difference.md)|历史去重与近邻文献访问边界|
|E095_parser|[outputs/095_anchored_minimal_contrast/parser_boundary_note.md](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/parser_boundary_note.md)|冻结parser的raw/core边界|
|E095_predictions|[outputs/095_anchored_minimal_contrast/unified_9065_predictions.jsonl](https://github.com/Nicoodoz/research-verifact/blob/28daf95e9b12270d8089246176023c66c4cf298e/outputs/095_anchored_minimal_contrast/unified_9065_predictions.jsonl)|需要患者级统计时回仓库获取；本包没有完整逐行副本|

## 当前写作包实际核对范围

已通过GitHub连接读取报告、关键代码、矩阵和转移文件，并将用于正文的聚合数值转录到`data/evidence.json`。6套8997矩阵按独立算式复算；两套转移张量的基线/候选边际与矩阵逐项相符。未在当前环境成功取得完整逐行文件，不声称重开私有原文或9065回执。原生逐行审计由上述独立子执行者报告支持。

引用患者区间时使用095报告/审计的发布精度；没有用聚合数据创建虚构患者。本次小修不附带新的研究计划，修改范围与检查说明见包根目录的`00_revision_notes_zh.md`。

## 本次外部近邻文献核对

- VitaminC：[ACL官方条目](https://aclanthology.org/2021.naacl-main.52/)，核对作者、标题、DOI和摘要范围。
- RAFTS：[ACL官方条目](https://aclanthology.org/2024.acl-long.556/)，核对检索、对比论据及示例机制的摘要描述。
- ACV：[出版方条目](https://www.mdpi.com/2227-7390/14/10/1769)，检索结果取得出版方摘要及日期/DOI；正文打开返回429，本包没有取得全文。因此只能作宽泛近邻说明，不声称完成算法级比较。

没有将上述论文的实验数字加入本地主表。参考文献编号1–15与正文一致；本次小修将[1]更新为VeriFact正式期刊版，其他条目维持原研究范围。

---

# 历史来源地图（继承至094）

本包实验快照：`5ec748edd63be29d35fa920f10874aa158501ae5`。以下链接均固定到该提交，不会因main后续变化悄悄换结果。报告引用与数值账本一起使用。

## 1 正文中的来源键

|来源键|原工件|用于本稿|
|---|---|---|
|E036|[outputs/036_final_validation/report.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/036_final_validation/report.md)|动机观察、R3571和表A5|
|E078|[outputs/078_component_ablation/report.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/078_component_ablation/report.md)|当前主结果、组件消融、192条桥接、成本|
|E078_tables|[outputs/078_component_ablation/performance_tables.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/078_component_ablation/performance_tables.md)|374共同有效与按作者敏感性|
|E084|[outputs/084_f4_coverage_validation/report.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/084_f4_coverage_validation/report.md)|F4历史背景；不与H956拼接|
|E090|[outputs/090_demo_constructor_repair_validation/report.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/090_demo_constructor_repair_validation/report.md)|P90原始队列及固定示例费用|
|E091|[outputs/091_integrated_evidence_decision_study/report.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/091_integrated_evidence_decision_study/report.md)|P167路径分解及其局限|
|E092|[outputs/092_task_adapted_verifier/report.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/092_task_adapted_verifier/report.md)|9,065全量监督对照、956缓存比较和训练协议|
|E092_tables|[outputs/092_task_adapted_verifier/detailed_tables.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/092_task_adapted_verifier/detailed_tables.md)|各类矩阵、935双方有效和924排除实际示例患者|
|E093|[outputs/093_lossless_evidence_budget/report.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/093_lossless_evidence_budget/report.md)|自然/压力FoldOnly/FoldAdd结果及成本|
|E093_cases|[outputs/093_lossless_evidence_budget/case_analysis.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/093_lossless_evidence_budget/case_analysis.md)|FS增加但正确数不变的机制边界|
|E094|[outputs/094_answer_isolated_verification/report.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/094_answer_isolated_verification/report.md)|问答V/Q结果及成本、问题人工审核|
|E094_cases|[outputs/094_answer_isolated_verification/case_analysis.md](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/outputs/094_answer_isolated_verification/case_analysis.md)|V/Q内容及有效性混杂|
|C009|[tasks/009_retrieval_baselines/baseline_config.json](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/tasks/009_retrieval_baselines/baseline_config.json)|候选容量、片段、打包/头预算|
|C053|[tasks/053_thinking_prior_validation/common053.py](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/tasks/053_thinking_prior_validation/common053.py)|PriorG变换、epsilon和平分顺序|
|C092|[tasks/092_task_adapted_verifier/train092.py](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/tasks/092_task_adapted_verifier/train092.py)|092训练是真正顶部微调，不属于主链|
|C093|[tasks/093_lossless_evidence_budget/operation093.py](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/tasks/093_lossless_evidence_budget/operation093.py)|机械可逆编码不是语义保证|
|C094|[tasks/094_answer_isolated_verification/method094.py](https://github.com/Nicoodoz/research-verifact/blob/5ec748edd63be29d35fa920f10874aa158501ae5/tasks/094_answer_isolated_verification/method094.py)|答案隔离和辅助字段的真实实现|

## 2 数值验证范围

`data/evidence.json` 保存聚合数值及混淆矩阵。含矩阵的H956、H935、H924、F9065、093及094主面板均按矩阵重算PA、MCC、AC1、Macro-F1和类别P/R，MCC/F1使用sklearn交叉核对。C384和R3571的部分指标按冻结报告转录，只重算了正确数对应PA；没有以不存在的逐例输入重算患者区间。

本包不是原仓库的完整镜像，不包含临床原文或API原始回执。因此不能仅凭本包重新执行检索、验证原文引用，或重新做患者bootstrap。需要这些检查时，按上表回到合法本地环境。

## 3 当前来源优先规则

发生冲突时，优先同一固定提交上的主报告/最新更正、详细指标和对应源码；不要用旧聊天摘要覆盖机器结果。若两份机器区间有差异，保留并解释，不挑有利一份。

重要校正：B/F4双方核心有效N935；N947只是排除B无效的一种融合补表范围。013/042/046/048/049等旧结果不能仅凭标题认定新机制已成功。原作者9,065条PA80.87%不等于其预印本摘要中另一口径的92.7%。

## 4 外部科学文献的核验入口

下列条目用于方法背景，未以其不同数据上的分数作本研究实验对照。完整BibTeX见包根目录。

- [VeriFact正式期刊版](https://doi.org/10.1056/AIdbp2500418)；[早期预印本](https://arxiv.org/abs/2501.16672)
- [VeriFact-BHC v1.1.0（版本、标签、引用）](https://physionet.org/content/mimic-iii-ext-verifact-bhc/1.1.0/)
- [FActScore](https://aclanthology.org/2023.emnlp-main.741/)
- [Calibration](https://proceedings.mlr.press/v70/guo17a.html)
- [QAGS](https://aclanthology.org/2020.acl-main.450/)
- [CoVe](https://aclanthology.org/2024.findings-acl.212/)
- [MiniCheck](https://aclanthology.org/2024.emnlp-main.499/)
- [MedNLI](https://aclanthology.org/D18-1187/)
- [M3-Embedding](https://arxiv.org/abs/2402.03216)
- [DeBERTaV3](https://arxiv.org/abs/2111.09543)
- [MIMIC-III](https://doi.org/10.1038/sdata.2016.35)
- [FEVER](https://aclanthology.org/N18-1074/)

本次能直接读取arXiv、ACL和PMLR页面及PhysioNet版本页。MIMIC论文出版商全文页和VeriFact正式NEJM AI正文页未能直接打开；正式出版元数据在PhysioNet条目交叉核对，未把未读正式正文的细节当已核实事实。

## 5 历史写作材料

原稿形成时参考过导师写作材料；本次仅小修既有稿件，不再附带这些材料。它们不属于本研究临床核验结果或外部算法证据。

## 模型与文字核对补充

092使用的具体checkpoint为 `MoritzLaurer/DeBERTa-v3-large-mnli-fever-anli-ling-wanli`，revision `b3546ea6b0346eb6f8d5d68b13c7dc6d0376b3d7`。正文[10]仅引用DeBERTa家族，[8]仅用于临床NLI相关工作；本稿不声称该checkpoint在MedNLI上训练。具体路径与参数见E092/C092。

正文式（4）使用D(M)表示后处理净正确变化，避免与PriorG中的校准偏置G重名。它是计数恒等式，不是新学习模块。


## 本次小修补充：历史G拟合实现

固定为095完成提交，不读取后续结果：

- `tasks/052_first_tier_validation/fit_calibration052.py`，提交 `28daf95e9b12270d8089246176023c66c4cf298e`。
- `obj_grad_hess`：G目标为平均NLL＋0.01×g²。
- `fit`：一维Newton，参数限制[-6,6]。
- `main`：仅使用051的16名校准患者；具体有效ID和计数由历史冻结工件决定。
- 正文参考文献[1]现使用VeriFact正式期刊版 DOI `10.1056/AIdbp2500418`；旧预印本仍可由 DOI `10.48550/arXiv.2501.16672` 定位。
