# Patient-Specific Clinical Fact Verification with a Frozen LLM: Full-Cohort Evaluation, False Support, and Evidence Constraints

**Authors, affiliations, and corresponding author:** [To be completed by the authors.]

## Abstract

Fact verification of clinical text requires aligning statements with the individual patient's electronic health record (EHR), rather than merely assessing their consistency with general medical knowledge. Retrieved evidence, model judgments, and class-decision rules jointly determine verification outcomes, and high agreement can conceal false support and losses in minority-class recognition. We construct a patient-specific verification pipeline without fine-tuning the core large language model (LLM), and separately evaluate evidence use and final decisions by reusing the same score outputs and analyzing per-proposition transitions. The system constructs a source-text evidence package through within-patient hybrid retrieval, obtains a native verdict and self-reported scores for three classes from a frozen LLM, and applies frozen class-prior and bias adjustments. We cover 100 patients and 9,065 valid atomic propositions in VeriFact-BHC, with paired comparisons against the original authors' released predictions on 8,997 propositions with valid core outputs for all compared methods. Percent agreement (PA) increases from 80.97% to 83.94%, Matthews correlation coefficient (MCC) from 0.4983 to 0.5976, and Macro-F1 from 0.5931 to 0.6663, while false-support predictions decrease from 564 to 347. The gain is primarily attributable to an increase in Not Addressed recall from 40.24% to 70.69%; Supported and Not Supported recall decrease by 1.63 and 3.35 percentage points, respectively. Applying the decision adjustment to the same native score outputs yields 685 additional correct predictions but also 180 additional false-support predictions, demonstrating the need to interpret overall gains together with risk trade-offs. A further source-constrained neighboring-proposition construction prototype revealed temporal and entity-binding problems during quality prechecks and did not proceed to final classification. These results show that a frozen core model can achieve favorable overall classification performance on this benchmark, while input traceability, auxiliary-construction validity, and downstream verification effectiveness require separate validation.

**Keywords:** clinical fact verification; electronic health records; retrieval augmentation; frozen large language models; false support; class decisions

## 1 Introduction

Clinical documents describe investigations, treatments, and disease trajectories for a particular patient at particular times, rather than general medical knowledge alone. A clinically reasonable treatment does not establish that the patient actually received it; likewise, the presence of a medication in the record does not fully support a statement about its administration time, dose, or purpose. For both human-written and LLM-generated hospital-course summaries, patient-specific fact verification must align individual propositions with the patient's reference EHR and identify content requiring review. VeriFact operationalizes this need through record retrieval and proposition-level judgments, and provides data and released system predictions that support reproducible evaluation [1,2].

Existing fact-verification approaches obtain discriminative information primarily through external-evidence organization and task-specific model learning. FActScore decomposes long-form text into atomic facts and checks source support, whereas QAGS evaluates summary factuality through question–answer consistency [3,5]. MiniCheck learns document–statement support relations from constructed training material [7]. Patient EHRs impose more specific constraints on evidence provenance. VeriFact combines retrieval-augmented generation with an LLM judge to apply off-the-shelf models to the patient's own records, without first training a new core classifier on labels from the target task [1,2]. This setting facilitates model reuse, but final performance remains jointly dependent on evidence content, reasoning configuration, and class-decision rules.

These influences require further separation in clinical three-class verification. Increasing the tendency to predict Supported can recover truly supported statements that were rejected too conservatively, but can also incorrectly accept true non-supported statements. Adding relevant source text or auxiliary propositions can change model outputs without necessarily providing useful new discriminative information. Comparing final agreement alone cannot establish whether an improvement comes from better evidence verification or from redistributing errors across classes. We therefore ask whether a pipeline with no fine-tuning of the core judge can achieve better overall performance than the original released system, and which auditable component effects and class trade-offs account for that performance.

Three challenges arise. First, the model sees only a limited retrieved evidence package, whereas clinician labels are based on the dataset's reference EHR; information absent from the package cannot be equated with information unaddressed by the full record. Second, clinical labels distinguish full support, incomplete support, and lack of coverage, and gains in majority-class correctness can conceal losses in the two non-Supported classes. Third, the native label, three-class scores, and final mapping from the same response can yield different decisions, while gains from auxiliary evidence may shrink after post-processing. Evaluation therefore requires both overall same-ID comparisons and separate examinations of class performance, native-to-final transitions, and source constraints.

Earlier controlled comparisons illustrated these challenges. A support bias applied to fixed scores increased the number of correct predictions but also increased false support. Under the same judge, a shorter evidence package and the released reference context produced similar final correct counts despite different native results. Native gains from demonstrations could also be matched by the baseline's own post-processing gains. These observations motivated separate evaluation of the evidence package, native judgment, and final class decision. For the subsequent evidence-anchored neighboring-proposition prototype, we additionally examined whether locating a string in the source was sufficient to establish that an edit changed only one attribute of the same event, rather than treating format validity as semantic validity.

Accordingly, our pipeline connects three stages: within-patient evidence construction, frozen-LLM scoring, and frozen class decisions. Source provenance, native outputs, and final predictions are retained together. We complete B request coverage for 9,065 target propositions from 100 patients, reevaluate the original released predictions and existing supervised models on a common valid set, and use historical component ablations to interpret system gains. The neighboring-proposition module completed construction and quality prechecks only, without producing final classification results. Its role here is to expose practical limits of source constraints, not to serve as an already effective core module.

This study makes three contributions:

1. **Full-cohort, same-ID evaluation with a frozen core judge.** On the common valid propositions from 100 patients, the system improves PA, MCC, and Macro-F1 while reducing false support. We explicitly report response coverage, validity, and class-wise differences from the original system.
2. **Explanation of overall gains and class-specific costs.** Using shared score outputs, standard controls, and per-proposition transitions, we distinguish true-support recovery, losses in non-Supported classes, and already incorrect predictions that become false support, without interpreting decision-boundary shifts as improved evidence understanding.
3. **Auditable boundaries for auxiliary evidence operations.** Fixed-input controls and source checks distinguish programmatic source binding, semantic correspondence to the same event, and downstream classification utility, providing concrete grounds for continuing or stopping an additional verification procedure.

The contributions are primarily empirical evaluation and interpretable analysis of a frozen system. We do not present hybrid retrieval, a fixed bias, or untested neighboring-proposition comparisons as new general-purpose algorithms. The following sections define the task and motivating observations, describe the system and experimental settings, and then discuss full-cohort results and their scope.

## 2 Task Definition and Motivating Observations

### 2.1 Propositions, Evidence, and Labels

Let $H$ denote a patient's reference record and $x$ an atomic proposition to be verified. The retriever constructs a limited evidence package $E=R(x,H)$, and the system outputs $\hat y\in\mathcal Y$, where $\mathcal Y=\{\mathrm S,\mathrm{NS},\mathrm{NA}\}$. Following the released task definitions, S denotes full support for the proposition; NS denotes that the relevant content is addressed but is incompletely or partially supported, or contradicted; and NA denotes that the reference record does not address the asserted fact [2]. We do not restrict NS to cases with explicit counterevidence, nor do we readjudicate clinician labels.

The label $y$ is defined relative to the dataset's reference EHR, whereas the model can inspect only $E$. Absence of information from the current package therefore neither establishes its absence from the complete record nor mechanically determines NS or NA. The original proposition remains the experimental unit; internally generated questions and neighboring propositions do not inherit its ground truth. Document-level error localization is an application objective, while this study evaluates the underlying proposition-verification component.

### 2.2 Observation 1: Correct Predictions and False Support Can Increase Together

Holding outputs fixed separates decision effects from model changes. In an earlier common valid set of 3,571 propositions from 40 held-out patients, changing the same non-reasoning scores from U0 decoding to fixed U2 decoding increased the correct count from 2,731 to 2,908 and false support from 81 to 204. Per-proposition decomposition identified 219 recovered true-S cases, 42 previously correct non-S cases made incorrect, and 81 already incorrect non-S cases further changed to S. A net gain of 177 correct predictions can therefore coexist with 123 additional false-support predictions.

This observation shows that a low-dimensional decision mapping can change the available operating point without adding input information. We therefore report classification performance, risk, and error transitions together. These results concern the earlier non-reasoning system and are not full-cohort evidence for the current T-S+PriorG pipeline.

### 2.3 Observation 2: Input Budget and Verification Utility Are Different Quantities

In a 192-proposition bridge comparison with the judge held fixed, the released reference context and C48 contained approximately 22,474 and 8,056 characters on average, respectively. Both yielded 162 correct predictions after the same T-S and PriorG stages, whereas their raw correct counts were 151 and 146. Shorter inputs reduced judge-call costs, but neither a classification advantage nor non-inferiority was established. Subsequent folding of exactly repeated source text likewise guaranteed only that the original package could be mechanically reconstructed, not that the freed space would be filled with decisive information.

Evidence construction must therefore answer at least two separate questions: how the material actually presented to the model changes, and whether that change improves the target classification. Provenance checks address part of the former; matched classification comparisons are required for the latter.

### 2.4 Observation 3: Upstream and Final Gains Must Be Linked Per Proposition

On 167 common valid propositions in a demonstration-compression comparison, F4 and P90 yielded 120 and 127 correct native predictions, respectively, but 135 and 137 correct final predictions. The native advantage shrank from 7 to 2 cases. This change included baseline recoveries that eliminated an earlier gap, lost native recoveries by the candidate, repairs of native harms, and newly introduced final-stage harms. Examining raw results alone can overstate deployment gains, while final differences alone can conceal upstream changes.

We therefore track outputs at each stage for the same IDs and locate gains through reproducible count decompositions, rather than inferring internal causal processes from model-generated reasons.

## 3 Verification System and Layered Analysis

### 3.1 Overview of the Three-Stage System

The system comprises within-patient evidence construction, a frozen judge, and a frozen class-decision stage (Figure 1). The evidence stage receives $(x,H)$ and returns source-attributed text $E$. The judge receives $(x,E)$ and returns a native label $r$, self-reported scores $s$, and a reason $q$. A decision mapping $f$ converts $s$ into the final label $\hat y$:

$$
(x,H)\xrightarrow{R}E,\qquad J(x,E)=(r,s,q),\qquad \hat y=f(s). \tag{1}
$$

The core judge's weights remain fixed. Historical class proportions and bias fitting used task labels, so “no fine-tuning of the core model” does not mean “no supervision.” The target proposition's clinician label (GT) is excluded from retrieval and model requests. We denote B's native output as B raw; in the results, B without a suffix such as raw abbreviates the complete no-demonstration T-S+PriorG system.

![Figure 1. Deployed pipeline and evaluation boundary](assets/fig01_framework_en.png)

**Figure 1. Deployed pipeline and evaluation boundary.** The diagram excludes the candidate final-verdict module that was not run in task 095. Arrows indicate actual data flow. Target-case GT is used only for evaluation and is not passed to the judge. Labels used for historical calibration are not expanded in the diagram.

### 3.2 Within-Patient Source-Text Evidence Construction

The evidence stage seeks to retain patient-relevant facts and their provenance within a limited context. It searches eligible records for the known patient and target admission, excluding the discharge summary containing the hospital-course text under evaluation. Passages are formed using paragraph boundaries and fixed-length splitting, with note identifiers, dates, times, and character positions retained. BM25 and BGE-M3 provide lexical and dense semantic candidates, respectively [9]. A frozen alternating merge rule combines them into at most 48 distinct candidates, which a BGE reranker then orders against the original claim.

Packing retains complete passages, with at most two passages per note and 16 passages in total. The nominal budget for note headers and text is 8,000 characters; an additional admission header is accounted for separately under the original implementation. Deduplication follows frozen conditions involving date, category, and text, and the final order is determined by date, time, note, and original position. Thus, C48 denotes candidate capacity, not a guarantee that the model reads 48 passages.

This stage supplies a fixed, traceable input foundation rather than claiming a new algorithm under the name of hybrid retrieval. The task-095 evaluation preserves distinct historical source branches and binds each case to its actual reference context. The locally completed BGE branch is not treated as byte-identical to historical API outputs.

### 3.3 Native Judgment and Scoring in One Response

The judge uses `deepseek-v4-flash-0731` with thinking-high, temperature 0, an output limit of 8,192 tokens, and no F4 demonstrations. A single response contains the native three-class verdict, reason/checks, and three-class `label_scores`, limiting additional variation from separate judgments. Historical non-reasoning controls used a 2,048-token limit. Mode comparisons therefore also involve different output budgets and cannot be attributed solely to differences in internal reasoning ability.

The self-reported scores $s_c$ are neither native token probabilities nor clinically calibrated posteriors. The native label $r$ and score-argmax decision U0 are defined and retained separately. Even when they coincide on the present common valid set, they are not two independently effective methods. A locatable citation establishes that a source exists, not that the reason is complete or the label correct.

### 3.4 Frozen Class Decisions

The decision stage adjusts class tendencies in fixed scores using historical parameters, without refitting them in task 095. We define

$$
\begin{aligned}
z_c &= \log\!\left(\max\{s_c/100,10^{-6}\}\right),\\
\hat y &= \arg\max_{c\in\mathcal Y}\left[z_c+\log\frac{\pi_{\mathrm{ref},c}}{\pi_{\mathrm{cal},c}}+g\,\mathbf{1}(c=\mathrm S)\right].
\end{aligned}\tag{2}
$$

In S/NS/NA order, $\pi_{\mathrm{ref}}=(1108,100,170)/1378$, $\pi_{\mathrm{cal}}=(48,47,48)/143$, and $g=0.1342909508820116$. These proportions and the bias originate from 16 historical calibration patients: 143 valid T-S score outputs were used to fit G, and 1,378 propositions were used to estimate the reference class proportions. G was fitted with the historical one-dimensional Newton implementation on $[-6,6]$, minimizing mean negative log-likelihood plus $0.01g^2$; none of these parameters was refitted in task 095. Ties follow the frozen priority order NS, NA, then S. This mapping is termed PriorG. G is a bias, not a two-model gate. By contrast, U2 adds only 2 to the S log score and is not equivalent to PriorG.

Equation (2) defines an empirical operating point and does not guarantee that the adjusted scores are true probabilities. Temperature scaling, multiclass bias adjustment, and vector scaling are established calibration approaches [4] and serve as controls here. Task 095 uses the complete frozen mapping without reselecting parameters from final results. Whether removing the small G bias preserves labels across the full cohort has not been reported; equality on 384 propositions cannot be extrapolated directly.

### 3.5 Native-to-Final and Class Transitions

To identify the stage at which outcomes change, let $n_{\mathrm{fix}}$ denote same-ID cases where the baseline is incorrect and the candidate correct, and let $n_{\mathrm{break}}$ denote cases where the baseline is correct and the candidate incorrect. Then

$$
\Delta C=n_{\mathrm{fix}}-n_{\mathrm{break}}. \tag{3}
$$

For the fixed-score pathway that changes a non-S prediction to S, let $n_{\mathrm{w2s}}$ additionally denote true non-S cases that were already misclassified and are then changed to S. Along this pathway, which contains only changes toward S, additional false support equals $n_{\mathrm{break}}+n_{\mathrm{w2s}}$. The latter group does not reduce the correct count a second time. These are therefore distinct evaluation quantities. More general native/final differences are counted separately; we do not assume that every candidate changes predictions only toward S.

For configuration $M$, let $C_r(M)$ and $C_f(M)$ denote native and final correct counts, respectively, and let $D(M)=C_f(M)-C_r(M)$. Two configurations satisfy

$$
C_f(M_1)-C_f(M_0)=C_r(M_1)-C_r(M_0)+D(M_1)-D(M_0). \tag{4}
$$

These are counting identities for checking results, not new theory or causal attribution. The reason $q$ remains associated with the native response; changing its label through $f$ does not automatically make that reason a valid explanation of the final decision.

### 3.6 Feasibility Prototype for Source-Anchored Neighboring Propositions

To examine whether explicit attribute differences could assist verification, we implemented a construction prototype. It selects one continuous span in the original claim, replaces it with a value locatable in C48, retains all other text, and generates at most one neighboring proposition. The replacement value must occur in the edited span and in one or two source quotations. Programmatic checks verify positions, source identifiers, and string relationships. A second frozen-model interface then checks for a single-attribute edit, a substantive difference, correspondence to the same event, and the absence of newly introduced facts.

The prototype does not require the neighboring proposition to be false, the two propositions to be mutually exclusive, or the neighboring proposition to be fully established by the evidence. It requires that the replacement value not be transferred into the retained event context without support. The preregistered excerpt control E supplies the same source anchors, whereas the contrastive arm C additionally supplies the neighboring proposition; the original claim remains the target of final evaluation. B/E/C were intended to separate excerpt effects from comparison effects. **Only construction and quality checks were completed; the final judges for E and C were not run.** We therefore use this prototype to analyze construction reliability and do not include it in the validated main pipeline in Equation (1).

## 4 Experimental Settings

### 4.1 Data, Response Coverage, and Valid Denominators

We use VeriFact-BHC v1.1.0, derived from 100 patients in MIMIC-III v1.4 [2,11]. The study includes 9,065 valid atomic propositions, retains the original GT, excludes 30 atomic propositions marked invalid by the existing validity annotations, and does not mix sentence-level units into the evaluation. The class counts are 7,035 S, 693 NS, and 1,337 NA; the human-written/LLM-generated counts are 5,624/3,441.

Task 095 obtained successful B response records for all 9,065 IDs. Of these, 8,997 had valid core score outputs and 9,034 had valid raw labels under the frozen parser; 68 were core-invalid. All methods are reevaluated on the former set for the main comparison, with class counts of 6,983 S, 687 NS, and 1,327 NA. Raw-label validity is reported separately, and results with different denominators are not directly subtracted. The core-invalid cases comprise 52 S, 6 NS, and 10 NA propositions: 41 responses ended at the output limit, and 27 stopped normally but failed the field contract. They are not completed with earlier answers, other models, or a default NA label.

**Table 1. Main sets and their evidential roles. Sets overlap and must not be added together as independent samples.**

| Set | Propositions / patients | Role | Validity and relationship |
|---|---:|---|---|
| Full-ID | 9,065 / 100 | All target IDs and response coverage | Not all have valid final classifications |
| F8997 | 8,997 / 100 | Main system comparison | B core-valid; all comparators reevaluated on the same IDs |
| Raw9034 | 9,034 / 100 | Supplementary B native-output coverage | Determined by the frozen parsing rules |
| C384 / Core374 | 384 / 24; 374 / 24 | Historical ablation of current components | C384 retains that run's frozen fallback; Core374 excludes the relevant invalid cases |
| E192 | 192 / 24 | Reference replacement with a fixed judge | Subset of C384; released contexts were not shortened |
| H956 | 956 / 24 | F4, text-model, and fusion comparisons | Historical mixed sampling; not a new full-cohort comparison |
| R3571 | 3,571 / 40 | Earlier boundaries and standard methods | Historical frozen confirmation, not the current T-S system |
| Construct300 | 300 | Task-095 construction-quality study | 200 natural and 100 enriched cases; final E/C classification not run |

Construction samples were determined before generation. The 200-case natural panel contains 162 S, 14 NS, and 24 NA propositions, while the 100-case enriched panel contains 34 S, 33 NS, and 33 NA propositions; results are reported separately. An 80-case discovery-oriented source review was separate from the construction sample. Its tags are overlapping researcher descriptions, not overall error prevalences or new medical gold labels.

### 4.2 Cache Selection and Actual Model Inputs

To avoid duplicate calls, task 095 scanned standardized native request records and selected one response per ID matching the current B configuration using a prespecified earliest-success-time and path rule, not label correctness. In total, 1,885 historical B responses were reused and 7,180 new B calls were made. Fourteen core-invalid historical responses were retained rather than resent because of unfavorable outcomes.

Actual reference contexts came from 3,675 historical task-032 inputs, 3,573 historical task-036 inputs, and 1,817 cases completed with local BGE in task 092. For every ID, we checked the original claim, reference hash, model, prompt, thinking settings, and output contract. Earlier non-thinking runs, F4, and other models were not treated as B. The main table therefore evaluates a frozen configuration across historical caches and newly completed calls, not a simultaneous rerun of all 9,065 cases. No new contemporaneous bridge was run in this task, and provenance stratification is not used to estimate randomized causal effects of implementation or time.

### 4.3 Comparators and Controlled Comparisons

Original always denotes the original authors' released system predictions on the same IDs, not a reconstruction using our newer model. The main table includes B raw, U2 applied to the same scores, the complete B+PriorG system, and task-092 Text-Frozen and Text-FT. The latter two read claim/C48 inputs directly and use neither T-S scores nor PriorG. Text-Frozen trains 6,148 aggregation/classification parameters, while Text-FT additionally updates the top DeBERTa layer, for a total of 12,602,372 trainable parameters [10]. In each of five folds, 64 patients are used for training, 16 for epoch selection, and 20 for outer-fold prediction. These patient-grouped out-of-fold (OOF) properties apply only to the corresponding text models, not to historical B predictions.

Historical ablations retain N-V/T-V, N-S/T-S, standard multiclass bias adjustment, and vector scaling to distinguish mode, scoring-interface, and decision effects. N/T denote non-thinking/thinking modes, and V/S denote output interfaces without/with three-class scores. StdM and StdV denote standard multiclass bias adjustment and vector scaling, respectively. F4 adds four fixed demonstrations; P90 compresses only demonstration references. Task 093 examines duplicate-text folding and evidence addition for the target case, whereas task 094 examines answer visibility. None becomes an effective component merely because task 095 completes full-cohort B coverage.

### 4.4 Quality, Risk, and Statistical Methods

We report PA, MCC, Gwet's AC1, Macro-F1, and per-class precision, recall, and F1. Macro-F1 is the unweighted mean of the F1 scores for S, NS, and NA. PA is the proportion of predictions agreeing with clinicians' three-class labels; the other metrics complement it by describing class confusion and chance-corrected agreement. False support is defined as predicting S for a true NS or NA case. We report its count and two denominators:

$$
\begin{aligned}
\mathrm{FS} &= \sum_i\mathbf{1}(y_i\ne\mathrm S,\hat y_i=\mathrm S),\\
\mathrm{FSR} &= \frac{\mathrm{FS}}{\sum_i\mathbf{1}(y_i\ne\mathrm S)},\\
\mathrm{FDR}_{\mathrm S} &= \frac{\mathrm{FS}}{\sum_i\mathbf{1}(\hat y_i=\mathrm S)}.
\end{aligned}\tag{5}
$$

FSR measures the false-acceptance rate among true non-S cases, whereas $\mathrm{FDR}_{\mathrm S}$ measures the error fraction among S predictions; the two are not interchangeable. If a panel contains no examples of a true class, that class's recall is not interpreted as a valid capability estimate. Fixed three-class Macro-F1 retains the existing zero-score convention.

Evaluation uses a unified implementation. Paired intervals are based on 1,000 patient-cluster bootstrap iterations with the observed predictions held fixed. They characterize differences for these samples and outputs, not uncertainty from historical method selection, model-service changes, or generalization to other hospitals. All patients had previously been used in the research, so this is not described as a new untouched test set. Batches, granularities, authorship groups, and validity scopes are kept distinct.

### 4.5 Engineering Verification and Cost

In task 095, a separate reviewer checked the identities, inputs, and labels of all selected request/response pairs by ID, recomputed the main metrics and paired patient intervals, and checked the costs of all 7,597 new calls. This independent review was a computational and provenance check by someone other than the implementer, not independent clinician annotation or external validation.

Costs are calculated from actual usage, cache fields, and applicable list prices. Incremental research expenses are separated from full deployment cost. Earlier experiments retain their original accounting basis; current off-peak prices are not applied retrospectively. GPU use, retrieval caches, labor, and API charges are separate categories, and zero incremental expense does not imply that the complete pipeline is free.

## 5 Results

### 5.1 Full-Cohort Comparison on the Common Valid Set

On the same 8,997 propositions, B+PriorG improves PA, MCC, Macro-F1, and AC1 while reducing false support relative to Original. Table 2 also retains native judgments and U2 applied to the same scores, showing that this advantage does not arise from native predictions that dominate every metric.

**Table 2. Main results on F8997: 100 patients and 2,014 true non-S cases. All rows use the same IDs; the best point estimate for each metric is bold.**

| Configuration | MCC ↑ | PA ↑ | Correct / 8,997 | Macro-F1 ↑ | AC1 ↑ | false-S ↓ |
|---|---:|---:|---:|---:|---:|---:|
| Original | 0.4983 | 80.97% | 7,285 | 0.5931 | 0.7661 | 564 |
| T-S raw | 0.5262 | 76.33% | 6,867 | 0.6242 | 0.6926 | **167** |
| T-S+U2 | 0.5713 | 81.53% | 7,335 | 0.6508 | 0.7664 | 274 |
| **B: T-S+PriorG** | **0.5976** | **83.94%** | **7,552** | **0.6663** | **0.7998** | 347 |
| Text-Frozen | 0.4444 | 79.52% | 7,154 | 0.5167 | 0.7496 | 756 |
| Text-FT | 0.5161 | 83.08% | 7,475 | 0.5568 | 0.7956 | 737 |

Relative to Original, B rescues 878 cases and harms 611, for 267 additional correct predictions. The PA difference is +2.97 percentage points, with a 95% patient-cluster interval of [1.84, 4.05]; the MCC difference is +0.0993, with an interval of [0.0780, 0.1188]. Macro-F1 increases by 0.0732. False support decreases by 217 cases, a relative reduction of 38.5%; FSR falls from 28.00% to 17.23%, and the error fraction among S predictions from 8.08% to 5.22%. Together, these metrics support an overall advantage on this benchmark, rather than a claim based solely on the highest accuracy.

![Figure 2. Classification quality and false support on the common valid full-cohort set](assets/fig02_full8997_tradeoff.png)

**Figure 2. MCC and false-support rate on F8997.** The horizontal FSR axis uses a fixed denominator of 2,014 true non-S cases; the vertical axis is MCC. Points represent fixed systems or operating points, not an optimized Pareto frontier. Text-FT uses patient-grouped OOF predictions, with a supervision scope different from B.

Response coverage and classification validity must be interpreted together. Across all 9,065 targets, B has 7,552 known correct final predictions. Counting the 68 responses without valid final scores as not correct yields a conservative correct proportion of 83.31%, rather than the 83.94% in the main table. This lower bound requires no invented labels, but those 68 cases cannot be assigned predictions to manufacture a full-cohort MCC. Raw validity uses its own denominator of 9,034 and is not directly contrasted with Table 2 across denominators.

### 5.2 Gains Primarily Reflect NA Recognition, Not Improvements in Every Minority Class

The full-cohort advantage has a specific class composition (Table 3). B correctly identifies 404 more NA cases than Original but 114 fewer S cases and 23 fewer NS cases, yielding the net gain of 267. This description is more precise than claiming stronger minority-class recognition overall: NA recall improves substantially and NS recall declines slightly, while NS precision increases from 26.65% to 31.76% and its F1 from 0.3461 to 0.3757.

**Table 3. Class performance and same-ID transitions on F8997.**

| True class | Denominator | Original recall | B recall | B precision | B F1 | B versus Original: rescued / harmed / net |
|---|---:|---:|---:|---:|---:|---|
| S | 6,983 | 91.82% | 90.19% | 94.78% | 0.9243 | 291 / 405 / -114 |
| NS | 687 | 49.34% | 46.00% | 31.76% | 0.3757 | 124 / 147 / -23 |
| NA | 1,327 | 40.24% | 70.69% | 69.12% | 0.6990 | 463 / 59 / +404 |

![Figure 3. Full-cohort class recall](assets/fig03_full8997_class_recall.png)

**Figure 3. Class recall for Original, B, and Text-FT on the same F8997 set.** Each class uses its own true-class denominator. Higher S recall for Text-FT does not imply better non-S judgments; Original retains slightly higher NS recall than B.

The reduction in false support involves both non-S classes: NS→S decreases from 250 to 158 and NA→S from 314 to 189. Nevertheless, B fails to identify 371 true NS cases, predicting S for 158 and NA for 213. Uniformly increasing the tendency to predict NS cannot be assumed to repair these errors, because B's NS predictions also contain 479 true S cases and 200 true NA cases. Further improvements must distinguish these competing errors rather than merely increase the frequency of one output class.

### 5.3 Stratification by Author, Patient, and Provenance

B's overall advantage does not imply higher accuracy in every subgroup. Table 4 shows a net gain of 298 correct human-written propositions but a net loss of 31 LLM-generated propositions; MCC and false support improve in both groups. The highly S-dominated LLM-generated subset is therefore an important exception to the overall accuracy result, and its accuracy gain cannot be inferred from pooled metrics.

**Table 4. F8997 stratified by proposition author.**

| Stratum | N | Original correct / PA | B correct / PA | MCC: Original → B | false-S: Original → B |
|---|---:|---|---|---|---|
| human | 5,577 | 4,100 / 73.52% | 4,398 / 78.86% | 0.4813 → 0.5922 | 459 → 274 |
| LLM | 3,420 | 3,185 / 93.13% | 3,154 / 92.22% | 0.3066 → 0.3576 | 105 → 73 |

![Figure 4. Net correct-count changes by author](assets/fig04_author_net_correct.png)

**Figure 4. Net change in correct predictions for B versus Original in the two authorship groups.** The vertical axis represents net counts, not percentages; subgroup sizes differ. The total gain is 298−31=267, while false support decreases by 185 and 32 cases, respectively.

Patient-level correct-count comparisons yield 61 wins, 32 losses, and 7 ties; 98 patients have at least one error rescued by B. These counts describe heterogeneity and do not replace overall proposition-level metrics. Across the task-032, task-036, and local-BGE reference branches, B has higher PA/MCC than Original on the same IDs. New-call and historical-cache strata show the same overall direction (Appendix A.3). Because patient and class compositions differ across these strata, between-stratum scores cannot be interpreted as causal evidence about local BGE quality or service drift.

### 5.4 Decision Gains and False-Acceptance Costs with Shared Scores

Relative to B raw, complete PriorG rescues 769 cases and harms 84 on F8997, increasing the correct count from 6,867 to 7,552. The PA difference is +7.61 percentage points, with a 95% patient-cluster interval of [6.93, 8.29]; the MCC difference is +0.0714, with an interval of [0.0614, 0.0811]. The three scores and source text are unchanged, so this gain can be attributed to the deterministic decision mapping, not to improved evidence understanding.

**Table 5. Raw→PriorG transitions on the same 8,997 propositions.**

| Path | S | NS | NA | Total and interpretation |
|---|---:|---:|---:|---|
| Incorrect → correct | 769 | 0 | 0 | 769; all are recovered true-S cases |
| Correct → incorrect | 0 | 76 | 8 | 84; previously correct non-S cases are changed to S |
| Already incorrect non-S → another incorrect prediction, S | Not applicable | 2 | 94 | 96; no further reduction in correct count, but additional false support |
| Additional false support | Not applicable | 78 | 102 | 180; 167→347 |

![Figure 5. Correct-count and false-support pathways under the decision mapping](assets/fig05_raw_to_final_counts.png)

**Figure 5. Two accounting views of the same B scores after PriorG.** The first three bars explain the net correct gain, 769−84=685; additional false support is 84+96=180. Categories denote transition pathways, not independently sampled groups.

This resolves an apparent contradiction: B+PriorG yields less false support than Original, but more than its own raw output. The reference conditions differ, so the two statements are not interchangeable. U2 produces 7,335 correct predictions and 274 false-support cases from the same scores. PriorG adds 217 correct predictions but also 73 false-support cases, reflecting the trade-offs between fixed operating points.

Historical C384 ablations provide further component controls. Moving from N-S raw to T-S raw adds 5 correct predictions and removes 6 false-support cases; moving from T-S raw to PriorG adds 32 correct predictions and 4 false-support cases. Prior-only and complete PriorG yield identical labels for every case in this set. Consequently, thinking mode, scoring interface, class proportions, and the small G bias cannot each be counted as separate innovations simply because they have different names. Task 095 establishes the existing system's full-cohort position; it does not provide a new randomized confirmation of every component.

### 5.5 Same-ID Comparison with Supervised Text-Based Alternatives

On F8997, B makes 77 more correct predictions than Text-FT, has an MCC higher by 0.0815, and produces 390 fewer false-support predictions. The PA difference is approximately +0.86 percentage points, with a patient-cluster interval of [−0.17, 1.90], so a PA advantage is not established; the MCC-difference interval is [0.0581, 0.1053]. B's NS/NA recalls are 46.00%/70.69%, compared with 8.88%/66.39% for Text-FT, whereas Text-FT has higher S recall. Thus, B offers a better overall trade-off than this particular supervised configuration, not evidence that all fine-tuning approaches are inferior.

The matched Frozen/FT experiment on all 9,065 propositions in task 092 retains separate significance: updating the top-level representation adds 326 correct predictions, comprising S +311, NS +17, and NA −2. It shows that the fixed training configuration outperforms its matched frozen encoder, but does not automatically justify replacing the current generative pipeline. The full-9065 text-model table and historical H956 fusion results are placed in the appendix to avoid direct main-table comparisons across different N.

### 5.6 Historical Controls for Evidence and Auxiliary Reasoning

With the judge fixed on E192, the released context and C48 both yield 162 correct T-S+PriorG predictions, with MCCs of 0.5774/0.5970 and false-support counts of 7/5, respectively. C48 uses shorter inputs and approximately 32% lower judge-call costs, but the MCC-difference interval includes zero and no non-inferiority margin was specified. The demonstrated value of the shorter package is therefore a budget trade-off, not an established accuracy contribution.

The full task-095 table does not convert tasks 093/094 into successful components. FoldAdd and B both make 76 correct predictions on the 88 common valid natural-panel cases, with one additional false-support case for FoldAdd; FoldAdd adds one correct prediction on the 30-case stress panel. IsolatedQA and B both achieve 19 correct predictions on 20 natural cases and 9 on 12 mechanism cases, but IsolatedQA introduces one additional false-support case in the latter panel. Its sole final advantage over visible-answer QA involves an invalid citation. P90's raw advantage over F4 likewise shrinks from +7 to +2 after final decoding. These results show that source preservation, answer isolation, and native gains do not substitute for evidence of final-system gains.

These controlled results have limited scope. We do not use them to reject all evidence processing, but retain three separate questions: whether an operation occurred, whether it supplied useful information, and whether it improved classification. Full controls and transition-path materials are provided in Appendix A.4.

### 5.7 Sufficient Construction Counts Do Not Establish Semantic Usability

The task-095 prototype obtained 300 successful construction responses. Of these, 117 passed literal source checks and proceeded to verification; 95 cases from 65 patients were automatically judged eligible for potential application, including 67 natural and 28 enriched cases. Counts met the continuation requirement, but semantic prechecks showed that automatic acceptance was unreliable (Table 6).

**Table 6. Completed scope of the task-095 neighboring-proposition prototype. Different checking levels cannot be combined into a classification accuracy.**

| Checking level | Observed count | Supported interpretation |
|---|---:|---|
| Construction executed | 300 | 200 natural + 100 enriched; a successful call is not necessarily a valid construction |
| Literal source binding passed | 117 | Replacement value, provenance, and span are locatable |
| Automatic semantic check passed | 95 / 65 patients | Proposed acceptance by the checker only |
| Automatically accepted cases among the initial 16 prechecks | 3 | 2 clear violations; 1 uncertain same-event match |
| Subsequent stratified quality review | 24 | 8 readable single-attribute edits, 8 clear violations, 8 undetermined |
| Final judges for E / C | **0 / 0** | No estimate of C−B or C−E classification effects |

![Figure 6. Construction-quality checks and final-classification status](assets/fig06_construction_stages.png)

**Figure 6. Execution status of the task-095 prototype.** The counts 300, 117, and 95 correspond to construction stages. The 24-case quality review is a stratified subsample of the 95 cases, not a new overall denominator. Final zeros mean that no final-judge requests were sent, not that classification accuracy was zero.

Source review revealed three main error types. First, a post-treatment value was inserted into a sentence that retained an initial time point: the literal value existed, but the temporal relation was misaligned. Second, a single continuous text span changed two medication states, or both fluid type and total volume; a single span was not necessarily a single attribute. Third, a value from another medication or event was assigned to the entity retained in the original proposition. Some synonymous abbreviation substitutions also failed to create a substantive factual contrast.

The 24 cases were a fixed sample of 12 natural and 12 enriched cases. The ratio 8/24 cannot be treated directly as the overall failure rate of the 95 cases, nor does “readable” certify a clinician-grounded truth. The prototype stopped before these problems were reliably resolved, without manually selecting favorable examples for final judging. This is therefore evidence of insufficient construction reliability, **not a 300-case classification experiment demonstrating that contrastive verification is ineffective**.

### 5.8 Cost, Parsing Validity, and Verification

Task 095 made 7,597 new calls, all returning HTTP 200 with no retries: 7,180 for B completion, 300 for construction, and 117 for checking. Based on actual applicable list prices and usage, the total estimated cost was CNY 95.769536: CNY 78.359575 for the initial baseline stage, CNY 1.946946 for construction/checking, and CNY 15.463016 for subsequent B completion. Rounding the components can produce a last-digit summation difference. This amount is not a reconciled account charge or the end-to-end deployment cost of rerunning all 9,065 cases, because historical responses, retrieval results, and reranking caches were reused, and the final E/C judges were not run.

Across all selected B responses, mean input/output usage was approximately 3,171/1,849 tokens, with medians of 3,161/1,496; output usage includes reasoning tokens. The 68 core-invalid responses are not 68 HTTP failures: 99.25% parsing coverage and 100% successful service-response coverage are different quantities. Diagnostics of recoverable raw labels and nonstandard JSON retain the frozen parser rather than retrospectively changing it to improve the main-table scores.

A historical same-input repeated subset also indicates that service outputs are not absolutely deterministic: among 385 common core-valid repeated cases, 39 final labels changed, and the latest responses yielded 5 fewer correct predictions than the earliest. This historically selected subset cannot estimate the fluctuation rate for all cases. Task 095 added neither repeat calls nor contemporaneous bridges, so batch-related limitations remain.

The independent review recomputed all main metrics, five paired comparisons, and costs, and checked that requests excluded GT. The accompanying manuscript package additionally checks aggregate arithmetic using public confusion matrices and transition tensors. These are respectively an audit of native records and a numerical check of the writing package; neither certifies clinical labels or the model's internal reasoning process.

## 6 Discussion and Limitations

### 6.1 Demonstrated System Gains and Method Contributions Not Yet Established

The full-cohort results extend earlier subset findings to a system evaluation covering all target IDs. B shows favorable overall directions relative to the released system in PA, MCC, Macro-F1, and false support. However, this advantage comes from the frozen pipeline and cannot be attributed to the neighboring-proposition final judge that was not run in task 095. The supported characteristics are the trade-off between NA recognition and lower false support, together with auditable stratified evidence. There is still no experimental basis for claiming that a new contrastive-reasoning algorithm improves clinical judgments.

This distinction also determines how the work relates to prior literature. An executable complex pipeline may not add useful information, and a simple system with better overall performance does not thereby contain a fundamentally new algorithm. We report these issues separately rather than enlarging the contribution through naming or by omitting simple controls.

### 6.2 Future Mechanisms Must First Preserve Event and Qualifier Relations

Construction failures indicate that a value in clinical source text must be interpreted together with its entity, event, time, and scope. A single string edit and a citation check constrain surface form but do not ensure that these relations are preserved. Further contrastive work should first bind editable attributes to immutable context explicitly, then test construction reliability without case-by-case manual selection. Merely adding an instruction to “pay attention to time” to the original checker does not address the present evidential gap.

This remains a research recommendation supported by failure cases, not an implemented method. Tags in the 80-case purposive source review overlap and include many unknowns, and the limited outside-package search did not establish a generalizable prevalence of missing evidence. We therefore do not conclude that retrieval is solved or that all remaining errors are reasoning errors.

### 6.3 Evaluation Scope and Transfer

The data comprise 100 patients already used in the research; full response coverage does not imply independent external testing. The main results use a fixed configuration and same-ID comparators, but caches span different periods, references include historical API and locally completed branches, and Original comes from the authors' historical system with a different judge. System-level differences therefore cannot be attributed exclusively to any single component. Stratified directions and patient intervals improve transparency but cannot eliminate composition and service differences. Text-FT's OOF design indicates only that the corresponding patient's data were not used for training or epoch selection; it does not give every comparator the same supervision protocol.

Clinician labels describe support relative to the supplied records, not direct certification of every fact in the real world. NS/NA boundaries, cross-record conflicts, and incomplete information may still require clinical adjudication. Researcher source review is not new expert gold annotation.

### 6.4 Proposition-Level Results and Clinical Use

Proposition outputs can support document review, but this study does not evaluate labels for newly and freely decomposed propositions, changes in clinician workload, or actual patient outcomes. Lower benchmark false support must not be reported as fewer medical incidents. Deployment additionally requires appropriate data permissions, runtime failure policies, consistency between reasons and final labels, and assessment of human-review burden. Retaining both native and final labels can prevent an unchanged reason from being displayed directly as a final explanation, but its user-facing utility requires separate evaluation.

## 7 Related Work

We organize related work by the source of discriminative information: external/patient evidence, auxiliary verification with fixed models, contrastive-information construction, and supervised learning or decision adjustment. The categories clarify comparison scope and are not assumed to be mutually exclusive.

### 7.1 General Sources and Patient-Specific Evidence

FEVER combines support/refutation/insufficient-information judgments with evidence identification [12], while FActScore assesses source support for atomic facts in long-form text [3]. Patient verification additionally requires evidence tied to the correct patient, event, and time. VeriFact applies retrieval and LLM judging to patient EHRs and provides annotations for both human-written and model-generated summaries [1,2]. We adopt this task and compare released predictions with a new frozen pipeline, rather than importing scores from medical question answering or encyclopedic fact-verification papers into the same main table.

### 7.2 Auxiliary Verification with Frozen Models

QAGS checks summary factuality through question–answer consistency, and CoVe uses independent verification questions to reduce the influence of an initial response [5,6]. The visible/isolated evidence-collection comparison in task 094 draws on these ideas, but the current single-question configuration did not yield a system-level gain. Its value is in identifying the effect boundaries of a specific fixed-input, fixed-interface implementation, not in claiming to have reproduced the original papers' gains in clinical three-class verification.

### 7.3 Contrastive Evidence, Arguments, and Neighboring Propositions

VitaminC uses closely related evidence pairs to examine sensitivity to factual changes and studies corresponding training procedures [13]. RAFTS constructs supporting/refuting arguments from retrieved evidence and combines them with demonstrations for verification [14]. These studies establish prior foundations for contrastive information and multi-perspective judgments. ACV's publisher abstract further describes atomic decomposition, graph-constrained variants, and item-wise comparisons [15]. At the study cutoff, its full text had not been obtained for implementation-level comparison, so we do not claim to originate the idea of neighboring propositions.

The local task-095 setting uses fixed patient-specific C48 evidence, single-attribute source anchoring, and an excerpt control; it does not reproduce those complete methods. It reveals reliability problems between value-level provenance and event-level relations but provides no final classification result. These references therefore establish methodological proximity, not performance baselines that were run in this study.

### 7.4 Supervised Verification and Low-Dimensional Decisions

MiniCheck studies document verification with constructed training material, and MedNLI provides a clinician-annotated clinical natural-language-inference task [7,8]. The supervised alternatives actually run here are Text-Frozen/Text-FT with matched inputs, not numerical results imported from other papers. Calibration research distinguishes temperature, class scaling, and bias [4]. We likewise separate changes in probabilities or scores from changes in labels, and do not treat frozen PriorG as new semantic information. A frozen core judge reduces the need to train a task model from scratch, but its utility remains determined by observed classification, provenance, and cost trade-offs.

## 8 Conclusion

We establish a traceable frozen-LLM pipeline for patient-EHR fact verification, complete response coverage for 9,065 target IDs from 100 patients, and conduct paired evaluation on 8,997 common valid propositions. Relative to the original VeriFact released system, B+PriorG improves PA, MCC, and Macro-F1 while reducing false support. Gains mainly reflect NA recognition, with costs in S and NS recall. Analysis of shared score outputs further shows that decision adjustment can recover true support while introducing additional false acceptance, and therefore must not be interpreted as new evidential information. The source-constrained neighboring-proposition prototype stopped at semantic quality prechecks and provides no classification-effect evidence. Future work should preserve current system strengths while improving the reliability of same-event, temporal, and scope constraints, before testing whether auxiliary verification adds value beyond simple excerpts.

## Data, Code, and Ethics Statement

This study uses de-identified VeriFact-BHC/MIMIC-III data subject to the applicable data-use conditions [2,11]. Clinical source text and private model-response records are not released with this manuscript. Code, aggregate predictions, and provenance fingerprints are managed under repository permissions.

**[To be completed by the authors]** Data-access credentials, ethics approval or exemption, permission for third-party API processing, funding, and competing-interest statements must be supplied from actual records. De-identification does not automatically authorize every form of third-party processing. This draft does not presume that these requirements have been completed.

## References

[1] Chung P, Swaminathan A, Goodell AJ, et al. Verifying Facts in Patient Care Documents Generated by Large Language Models Using Electronic Health Records. NEJM AI, 2026, 3(1). DOI: 10.1056/AIdbp2500418.

[2] Chung P, Swaminathan A, Goodell A, et al. MIMIC-III-Ext-VeriFact-BHC: Labeled Propositions From Brief Hospital Course Summaries for Long-form Clinical Text Evaluation. PhysioNet, version 1.1.0, 2026. DOI: 10.13026/7cqh-bc36.

[3] Min S, Krishna K, Lyu X, et al. FActScore: Fine-grained Atomic Evaluation of Factual Precision in Long Form Text Generation. EMNLP, 2023. DOI: 10.18653/v1/2023.emnlp-main.741.

[4] Guo C, Pleiss G, Sun Y, Weinberger KQ. On Calibration of Modern Neural Networks. ICML, PMLR 70:1321–1330, 2017.

[5] Wang A, Cho K, Lewis M. Asking and Answering Questions to Evaluate the Factual Consistency of Summaries. ACL, 2020. DOI: 10.18653/v1/2020.acl-main.450.

[6] Dhuliawala S, Komeili M, Xu J, et al. Chain-of-Verification Reduces Hallucination in Large Language Models. Findings of ACL, 2024. DOI: 10.18653/v1/2024.findings-acl.212.

[7] Tang L, Laban P, Durrett G. MiniCheck: Efficient Fact-Checking of LLMs on Grounding Documents. EMNLP, 2024. DOI: 10.18653/v1/2024.emnlp-main.499.

[8] Romanov A, Shivade C. Lessons from Natural Language Inference in the Clinical Domain. EMNLP, 2018. DOI: 10.18653/v1/D18-1187.

[9] Chen J, Xiao S, Zhang P, Luo K, Lian D, Liu Z. M3-Embedding: Multi-Linguality, Multi-Functionality, Multi-Granularity Text Embeddings Through Self-Knowledge Distillation. arXiv:2402.03216, 2024. DOI: 10.48550/arXiv.2402.03216.

[10] He P, Gao J, Chen W. DeBERTaV3: Improving DeBERTa Using ELECTRA-Style Pre-Training with Gradient-Disentangled Embedding Sharing. ICLR, 2023. arXiv:2111.09543.

[11] Johnson AEW, Pollard TJ, Shen L, et al. MIMIC-III, a Freely Accessible Critical Care Database. Scientific Data, 3:160035, 2016. DOI: 10.1038/sdata.2016.35.

[12] Thorne J, Vlachos A, Christodoulopoulos C, Mittal A. FEVER: a Large-scale Dataset for Fact Extraction and VERification. NAACL, 2018. DOI: 10.18653/v1/N18-1074.

[13] Schuster T, Fisch A, Barzilay R. Get Your Vitamin C! Robust Fact Verification with Contrastive Evidence. NAACL, 2021: 624–643. DOI: 10.18653/v1/2021.naacl-main.52.

[14] Yue Z, Zeng H, Shang L, et al. Retrieval Augmented Fact Verification by Synthesizing Contrastive Arguments. ACL, 2024: 10331–10343. DOI: 10.18653/v1/2024.acl-long.556.

[15] Kim HG, Jun TS, Lee T. Atomic Contrastive Verification: Fine-Grained Fact-Checking via Claim Decomposition and Knowledge Graph-Grounded Contrastive Reasoning. Mathematics, 2026, 14(10):1769. DOI: 10.3390/math14101769.

## Appendix A. Supplementary Results and Reproducibility Information

### A.1 Complete Confusion Matrices for the Main Table

Rows below are true S/NS/NA classes and columns are predicted S/NS/NA classes; all matrices use N=8,997. Machine-readable data are stored at `cohorts.F8997` in `data/evidence.json`; these are not patient-level source texts.

```text
Original    [[6412,454,117], [250,339,98],  [314,479,534]]
B raw       [[5529,1242,212],[80,392,215], [87,294,946]]
T-S+U2      [[6053,724,206], [130,344,213],[144,245,938]]
B+PriorG    [[6298,479,206], [158,316,213],[189,200,938]]
Text-Frozen [[6227,80,676],  [335,44,308], [421,23,883]]
Text-FT     [[6533,49,401],  [359,61,267], [378,68,881]]
```

### A.2 Text-Model Results on All 9,065 Propositions

**Table A1. Full-9065 comparison of released predictions and the two text models only. These values must not be directly subtracted from the 8997 main-table results.**

| Configuration | Correct | PA | MCC | Macro-F1 | false-S / 2030 |
|---|---:|---:|---:|---:|---:|
| Original | 7,331 | 80.87% | 0.4959 | 0.5918 | 573 |
| Text-Frozen | 7,204 | 79.47% | 0.4433 | 0.5167 | 764 |
| Text-FT | 7,530 | 83.07% | 0.5156 | 0.5569 | 745 |

![Figure A1. Class-wise net correct-count changes for full-9065 text adaptation](assets/figA1_text_adaptation_gain.png)

**Figure A1. Class-wise net correct-count differences for Text-FT versus Text-Frozen.** Inputs and aggregation heads are matched: S +311, NS +17, and NA −2. This result does not represent all fine-tuning schemes and is not a training ablation of B.

### A.3 Provenance and Batch Strata

**Table A2. F8997 stratified by actual evidence provenance. The strata are not randomized controls.**

| Stratum | N | Original correct / PA | B correct / PA | MCC: Original → B | false-S: Original → B |
|---|---:|---|---|---|---|
| 032 | 3,649 | 2,953 / 80.93% | 3,065 / 84.00% | 0.4786 → 0.5917 | 231 → 123 |
| 036 | 3,547 | 2,853 / 80.43% | 2,958 / 83.39% | 0.5209 → 0.6077 | 230 → 146 |
| Local BGE | 1,801 | 1,479 / 82.12% | 1,529 / 84.90% | 0.4855 → 0.5840 | 103 → 78 |

**Table A3. New B calls and historical-cache strata. Differences in composition preclude using these strata to quantify service drift.**

| Stratum | N | Original correct / PA | B correct / PA | MCC: Original → B | false-S: Original → B |
|---|---:|---|---|---|---|
| 095 new | 7,126 | 5,809 / 81.52% | 5,997 / 84.16% | 0.5040 → 0.5954 | 418 → 271 |
| Historical cache | 1,871 | 1,476 / 78.89% | 1,555 / 83.11% | 0.4780 → 0.6044 | 146 → 76 |

### A.4 Historical Component and Candidate Results

**Table A4. Main component comparisons on C384. The frozen fallback for that run is retained; this is not a fallback-free core-valid table.**

| Configuration | Correct / 384 | MCC | false-S | Fallback |
|---|---:|---:|---:|---:|
| Original | 310 | 0.4840 | 19 | 0 |
| N-S raw | 284 | 0.4406 | 12 | 0 |
| N-S+U2 | 310 | 0.4708 | 23 | 0 |
| N-S+StdM | 320 | 0.4955 | 27 | 0 |
| N-S+StdV | 319 | 0.4876 | 27 | 0 |
| T-S raw | 289 | 0.5019 | 6 | 6 |
| T-S+U2 | 307 | 0.5430 | 9 | 6 |
| T-S+prior-only | 321 | 0.5887 | 10 | 6 |
| T-S+PriorG | 321 | 0.5887 | 10 | 6 |

Among 374 common core-valid cases across the relevant conditions, B yields 313 correct predictions/MCC 0.5875/false support 10, versus 302/0.4834/19 for Original. In the historical mixed H956 comparison, B/F4/text fusion yield 783/793/795 correct predictions and 41/52/64 false-support cases. Neither F4 nor fusion justifies an overall default-system upgrade. This set overlaps with other historical samples and is not an independent replication.

**Table A5. Fixed decision boundaries and standard controls on the earlier R3571 set.**

| Method | Correct / 3571 | PA | MCC | false-S | NS / NA recall |
|---|---:|---:|---:|---:|---|
| Original | 2,866 | 80.26% | 0.5173 | 233 | 52.00% / 41.71% |
| N-S+U0 | 2,731 | 76.48% | 0.5293 | 81 | 64.36% / 54.19% |
| N-S+U2 | 2,908 | 81.43% | 0.5520 | 204 | 50.55% / 53.53% |
| Gate A | 2,886 | 80.82% | 0.5621 | 141 | 56.00% / 54.19% |
| StdM | 2,999 | 83.98% | 0.5850 | 251 | 37.45% / 61.25% |
| StdV | 3,004 | 84.12% | 0.5850 | 254 | 10.55% / 73.40% |

**Table A6. Final paired results for the candidates run in tasks 093/094. Panels are not pooled.**

| Operation / panel | B correct | Candidate correct | MCC: B→candidate | false-S: B→candidate |
|---|---:|---:|---|---|
| FoldAdd / natural core | 76/88 | 76/88 | 0.6250→0.6130 | 1→2 |
| FoldAdd / non-S stress | 17/30 | 18/30 | 0.4103→0.4382 | 10→9 |
| IsolatedQA / natural | 19/20 | 19/20 | 0.7935→0.7935 | 0→0 |
| IsolatedQA / mechanism | 9/12 | 9/12 | 0.6316→0.6316 | 0→1 |

Task 095 is excluded from Table A6 because it has no final candidate classifications. Historical P90 transition plots and other figure sources remain in the accompanying package and can be used as supplementary material where space permits; they need not all appear in a short conference paper.

### A.5 Validity, Accounting, and Computational Verification

Thirty-seven B responses are raw-valid but core-invalid, and another 31 are raw-invalid under the frozen parser. Some of the 41 nonstandard-JSON responses contain recoverable native labels, so parsing invalidity must not uniformly be described as producing no label at all. The main table retains the frozen rules; parsing strategy is not altered during manuscript preparation. Any new format-recovery study should be registered separately and distinguished from semantic rejudging.

Native audit artifacts are recorded in task 095's `final_review.md` and associated machine checks. The package's `data/095_aggregate_audit.json` records checks of public matrices and transition arithmetic. Patient-bootstrap intervals come from repository reports and the independent audit; patient resampling is not reconstructed from aggregate matrices in this package. Reproducibility sources and fixed-commit locations are listed in `sources/reference_map.md`, including the historical G-fitting code. Run `python scripts/check_package.py` to recheck aggregate arithmetic and package resource links. Figures 2–6 can be rebuilt offline with `python scripts/build_figures.py`; historical supplementary figures are rebuilt with `python scripts/build_historical_figures.py`.
