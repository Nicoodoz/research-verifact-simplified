"""Rebuild task095 manuscript figures from public aggregate counts; no API calls.

Python 3.10+, numpy and matplotlib are sufficient. No private patient text is
required. Each chart is a separate figure; historical figures remain separate.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets'

def save(fig, name):
    OUT.mkdir(exist_ok=True)
    fig.tight_layout()
    fig.savefig(OUT/f'{name}.png',dpi=220,bbox_inches='tight')
    fig.savefig(OUT/f'{name}.svg',bbox_inches='tight')
    plt.close(fig)

def main():
    data=json.loads((ROOT/'data/evidence.json').read_text(encoding='utf-8'))
    rows={r['method']:r for r in data['cohorts']['F8997']['rows']}
    plt.rcParams.update({'font.size':11,'svg.fonttype':'none'})
    fig,ax=plt.subplots(figsize=(9,5.3))
    names=['Original','B raw','B+U2','B+PriorG','Text-Frozen','Text-FT']
    offsets={'Original':(8,-15),'B raw':(8,5),'B+U2':(8,5),'B+PriorG':(8,5),'Text-Frozen':(-102,-2),'Text-FT':(-78,8)}
    for n,mark in zip(names,['o','s','^','*','D','P']):
        r=rows[n];x=r['FSR']*100;y=r['MCC']
        ax.scatter(x,y,marker=mark,s=135 if n=='B+PriorG' else 65)
        ax.annotate({'B raw':'T-S raw','B+U2':'T-S+U2'}.get(n,n),(x,y),xytext=offsets[n],textcoords='offset points',fontsize=10)
    ax.set(xlabel='False support / true non-S (%) — lower is better',ylabel='MCC — higher is better',title='Same 8,997 core-valid claims, 100 patients',xlim=(5,42),ylim=(.415,.625))
    ax.text(.02,.02,'Fixed configurations; not an optimized frontier.',transform=ax.transAxes,fontsize=9)
    ax.grid(linestyle=':',alpha=.3);save(fig,'fig02_full8997_tradeoff')

    fig,ax=plt.subplots(figsize=(9,5.3));x=np.arange(3);width=.25
    for i,n in enumerate(['Original','B+PriorG','Text-FT']):
        vals=np.array(rows[n]['recall'])*100
        bars=ax.bar(x+(i-1)*width,vals,width,label=n)
        for b,v in zip(bars,vals):
            ax.annotate(f'{v:.1f}',(b.get_x()+b.get_width()/2,v),xytext=(0,4),textcoords='offset points',ha='center',fontsize=9)
    ax.set(xticks=x,xticklabels=['S (n=6,983)','NS (n=687)','NA (n=1,327)'],ylabel='Recall (%)',ylim=(0,112),title='Class-wise recall on the same 8,997 claims')
    ax.legend(ncol=3,loc='upper center',frameon=False,fontsize=10)
    ax.grid(axis='y',linestyle=':',alpha=.3);ax.set_axisbelow(True);save(fig,'fig03_full8997_class_recall')

    ss=data['strata095']['author'];delta=[r['B_correct']-r['Original_correct'] for r in ss]
    fig,ax=plt.subplots(figsize=(8.4,4.9));bars=ax.bar([f"{r['stratum']} (n={r['N']:,})" for r in ss],delta,width=.52)
    for b,v in zip(bars,delta):
        ax.text(b.get_x()+b.get_width()/2,v+(8 if v>=0 else -8),f'{v:+,}',ha='center',va='bottom' if v>=0 else 'top')
    ax.axhline(0,linewidth=.9)
    ax.set(ylabel='Net additional correct predictions (B minus Original)',title='Overall gain is concentrated in human-written claims',ylim=(-85,360))
    ax.text(.97,.95,'Total: +267',transform=ax.transAxes,ha='right',va='top',fontsize=10)
    ax.grid(axis='y',linestyle=':',alpha=.3);ax.set_axisbelow(True);save(fig,'fig04_author_net_correct')

    fig,ax=plt.subplots(figsize=(9.2,5.3));vals=[769,84,685,96,180]
    bars=ax.bar(np.arange(5),vals,width=.62)
    for b,v in zip(bars,vals):ax.text(b.get_x()+b.get_width()/2,v+13,str(v),ha='center')
    ax.set(xticks=np.arange(5),xticklabels=['Rescued\ntrue S','Harmed\nnon-S','Net\ncorrect gain','Wrong non-S\nto wrong S','Additional\nfalse support'],ylabel='Claims',ylim=(0,875),title='One frozen score vector: raw → PriorG')
    ax.text(.99,.97,'769 − 84 = 685;  84 + 96 = 180',transform=ax.transAxes,ha='right',va='top',fontsize=9)
    ax.tick_params(axis='x',labelsize=9);ax.grid(axis='y',linestyle=':',alpha=.3);ax.set_axisbelow(True);save(fig,'fig05_raw_to_final_counts')

    fig,ax=plt.subplots(figsize=(9.2,5.2));labels=['Constructed','Source-bound','Auto-eligible','Final E Judge','Final C Judge'];vals=[300,117,95,0,0]
    bars=ax.barh(labels,vals,height=.58);ax.invert_yaxis()
    for b,v in zip(bars,vals):
        ax.text(v+4,b.get_y()+b.get_height()/2,str(v)+( ' (not run)' if v==0 else ''),va='center',fontsize=10)
    ax.set(xlabel='Calls / cases at each specified stage (not accuracy)',xlim=(0,357),title='Task 095 stopped before E/C classification')
    ax.text(.96,.02,'Separate stratified quality sample (n=24):\n8 readable / 8 violations / 8 unknown',transform=ax.transAxes,ha='right',va='bottom',fontsize=9)
    ax.grid(axis='x',linestyle=':',alpha=.3);ax.set_axisbelow(True);save(fig,'fig06_construction_stages')
    print('Created 5 task095 figure pairs (PNG + SVG). Historical figures preserved.')

if __name__=='__main__':main()
