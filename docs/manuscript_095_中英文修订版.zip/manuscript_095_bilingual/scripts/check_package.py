"""Offline checks for the bilingual task-095 manuscript package.

Uses the Python standard library. Checks arithmetic from aggregate matrices,
Markdown structure, figure resources, and numeric table/TeX correspondence.
This is not a review of private patient-level responses or clinical labels.
"""
from pathlib import Path
import json, math, re

ROOT=Path(__file__).resolve().parents[1]
DOCS=['01_manuscript_zh.md','02_manuscript_en.md']

def matrix_metrics(cm):
    n=sum(map(sum,cm)); k=len(cm)
    tr=sum(cm[i][i] for i in range(k))
    true=[sum(r) for r in cm]
    pred=[sum(cm[i][j] for i in range(k)) for j in range(k)]
    den=(n*n-sum(v*v for v in true))*(n*n-sum(v*v for v in pred))
    mcc=(tr*n-sum(a*b for a,b in zip(true,pred)))/math.sqrt(den) if den else 0.0
    f1=[2*cm[i][i]/(true[i]+pred[i]) if true[i]+pred[i] else 0.0 for i in range(k)]
    pooled=[(a+b)/(2*n) for a,b in zip(true,pred)]
    chance=sum(v*(1-v) for v in pooled)/(k-1)
    return {'N':n,'correct':tr,'PA':tr/n,'MCC':mcc,'Macro_F1':sum(f1)/k,
            'AC1':(tr/n-chance)/(1-chance),'false_S':sum(cm[i][0] for i in range(1,k))}

def tables(text):
    return [x for x in re.split(r'\n\s*\n',text) if x.startswith('|')]

def table_values(text):
    # Numeric token order in each data cell; translated headers are excluded.
    ans=[]
    for table in tables(text):
        rows=[]
        for line in table.splitlines()[2:]:
            vals=[]
            for cell in line.strip().strip('|').split('|'):
                # Minus signs in task-095 are linguistic; true negative values
                # in table cells keep their signs below.
                cell=re.sub(r'task-(\d+)',r'task \1',cell,flags=re.I)
                v=re.findall(r'[+−-]?\d+(?:,\d{3})*(?:\.\d+)?',cell)
                vals.append([x.replace(',','').replace('−','-').lstrip('+') for x in v])
            rows.append(vals)
        ans.append(rows)
    return ans

def main():
    checks=[]
    def check(ok,label):
        if not ok: raise AssertionError(label)
        checks.append(label)
    docs={fn:(ROOT/fn).read_text(encoding='utf-8') for fn in DOCS}
    for fn,s in docs.items():
        check('<!--' not in s and '-->' not in s,fn+': no HTML editorial comments')
        check(not re.search(r'(?<!\d)09[67](?!\d)',s),fn+': no post-095 task results')
        check(re.findall(r'^## ([1-8]) ',s,re.M)==[str(i) for i in range(1,9)],fn+': eight main sections')
        check(re.findall(r'^\[(\d+)\] ',s,re.M)==[str(i) for i in range(1,16)],fn+': 15 ordered bibliography entries')
        check(re.findall(r'\\tag\{(\d+)\}',s)==[str(i) for i in range(1,6)],fn+': five numbered equations')
        check(s.count('```')%2==0,fn+': balanced code fences')
        check(len(re.findall(r'^\$\$$',s,re.M))==10,fn+': balanced display math')
        check(len(tables(s))==12,fn+': 12 tables')
        for table in tables(s):
            widths={len(x.strip().strip('|').split('|')) for x in table.splitlines()}
            check(len(widths)==1,fn+': consistent table columns '+table.splitlines()[0][:40])
        links=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',s)
        check(len(links)==7,fn+': seven embedded figures')
        for link in links:check((ROOT/link).is_file(),fn+': image exists '+link)
    a,z=docs[DOCS[0]],docs[DOCS[1]]
    check(re.findall(r'\$\$\n(.*?)\n\$\$',a,re.S)==re.findall(r'\$\$\n(.*?)\n\$\$',z,re.S),'identical bilingual displayed equations')
    check(table_values(a)==table_values(z),'identical bilingual numeric table cells')
    check(not re.search(r'[\u4e00-\u9fff]',z),'English manuscript: no untranslated Chinese')
    data=json.loads((ROOT/'data/evidence.json').read_text())
    check(data['snapshot']=='28daf95e9b12270d8089246176023c66c4cf298e','095 source snapshot retained')
    main_rows=data['cohorts']['F8997']['rows']
    for row in main_rows:
        m=matrix_metrics(row['confusion_matrix'])
        for k in m:
            check(abs(m[k]-row[k])<1e-10,f"F8997 {row['method']}: {k}")
    T=data['transitions095']
    for key in ['Original_to_B','raw_to_B']:
        t=T[key]['tensor']; fixes=harms=0
        for g in range(3):
            for base in range(3):
                for new in range(3):
                    c=t[g][base][new]
                    fixes+=c*(base!=g and new==g)
                    harms+=c*(base==g and new!=g)
        check(fixes==T[key]['rescues'],key+': rescues')
        check(harms==T[key]['harms'],key+': harms')
        check(fixes-harms==T[key]['net'],key+': net correct')
    check(1885+7180==9065 and 8997+68==9065 and 8997+37==9034,'coverage arithmetic')
    check(769-84==685 and 84+96==180,'raw-to-final arithmetic')
    for strata in ['author','evidence_source','call_source']:
        rows=data['strata095'][strata]
        for key,expected in [('Original_correct',7285),('B_correct',7552),('Original_false_S',564),('B_false_S',347)]:
            check(sum(r[key] for r in rows)==expected,strata+': '+key)
    c=data['cost095']
    check(abs(c['baseline_initial']+c['construction_checker']+c['baseline_completion']-c['total_tariff_estimate_cny'])<1e-10,'unrounded cost components sum')
    for path in ['references.bib','sources/reference_map.md','data/095_aggregate_audit.json',
                 'scripts/build_figures.py','scripts/build_historical_figures.py']:
        check((ROOT/path).is_file(),'supplement exists: '+path)
    report={'status':'PASS','scope':'Aggregate arithmetic, Markdown resources, and bilingual correspondence only; no private-response or clinical audit.',
            'checks_passed':len(checks),'checks':checks}
    (ROOT/'data/revision_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('PASS:',len(checks),'checks; see data/revision_checks.json')
if __name__=='__main__':main()
