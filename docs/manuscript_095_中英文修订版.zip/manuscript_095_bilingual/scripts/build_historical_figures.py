"""Rebuild manuscript figures from source-checked aggregate data; no network/API calls.

Requires Python 3.10+, numpy and matplotlib. Each figure is a separate plot.
No model output, patient text, font file or paid inference is required.
"""
from __future__ import annotations
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets'

def save(fig: plt.Figure, stem: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f'{stem}.png', dpi=240, bbox_inches='tight')
    fig.savefig(OUT / f'{stem}.svg', bbox_inches='tight')
    plt.close(fig)

def main() -> None:
    data = json.loads((ROOT / 'data/evidence.json').read_text(encoding='utf-8'))
    plt.rcParams.update({'font.size': 11, 'svg.fonttype': 'none'})
    rows = {r['method']: r for r in data['cohorts']['C384']['rows']}
    fig, ax = plt.subplots(figsize=(8.7, 5.0))
    names = ['Original', 'N-S + U2', 'N-S + StdM', 'N-S + prior-only', 'T-S raw', 'T-S + U2', 'B + PriorG']
    offsets = {'Original':(8,5),'N-S + U2':(8,-13),'N-S + StdM':(8,-5),'N-S + prior-only':(8,5),'T-S raw':(8,5),'T-S + U2':(8,5),'B + PriorG':(8,2)}
    for name, marker in zip(names, ['o','s','^','D','P','v','*']):
        row = rows[name]
        ax.scatter(row['false_S'], row['MCC'], marker=marker, s=120 if name=='B + PriorG' else 65)
        ax.annotate(name, (row['false_S'],row['MCC']), xytext=offsets[name], textcoords='offset points', fontsize=10)
    ax.set(xlabel='False Supported predictions (count; lower is better)', ylabel='MCC (higher is better)',
           title='Fixed configurations on the same 384 claims', xlim=(3,37), ylim=(.448,.615))
    ax.grid(True, linestyle=':', alpha=.35)
    fig.tight_layout()
    save(fig,'fig02_c384_tradeoff')

    co = data['cohorts']['H956']; rr={r['method']:r for r in co['rows']}
    fig, ax=plt.subplots(figsize=(8.7,5.1)); x=np.arange(3); width=.24
    for i,name in enumerate(['Original','B + PriorG','F4 + PriorG']):
        values=np.array(rr[name]['recall'])*100
        rects=ax.bar(x+(i-1)*width,values,width,label=name)
        for bar,value in zip(rects,values):
            ax.annotate(f'{value:.1f}',(bar.get_x()+bar.get_width()/2,bar.get_height()),xytext=(0,4),textcoords='offset points',ha='center',fontsize=9)
    ax.set(xticks=x,xticklabels=['Supported (n=725)','Not Supported (n=102)','Not Addressed (n=129)'],ylabel='Class recall (%)',ylim=(0,109),title='Class-wise recall on the same 956 cached claims')
    ax.legend(loc='upper center',ncol=3,frameon=False,fontsize=9)
    ax.grid(axis='y',linestyle=':',alpha=.3);ax.set_axisbelow(True)
    fig.tight_layout();save(fig,'fig03_h956_class_recall')

    p=data['P90_path']; labels=['Raw\nadvantage','F4 catches up\non true S','P90 NS\nrescue lost','Raw harms\nrepaired','New final\nlayer harms','Final\nadvantage']
    vals=[p['raw_gain']]+[a['delta'] for a in p['path_changes']]+[p['final_gain']]
    fig,ax=plt.subplots(figsize=(9.4,5.1)); cumulative=0
    for i,val in enumerate(vals):
        if i in (0,len(vals)-1):
            bottom=0; height=val; level=val
            if i==0:cumulative=val
        else:
            prev=cumulative;cumulative+=val;bottom=min(prev,cumulative);height=abs(val);level=cumulative
        ax.bar(i,height,bottom=bottom,width=.66)
        ax.text(i,bottom+height+.17,f'{val:+d}',ha='center',fontsize=11)
        if i<len(vals)-1:
            ax.plot([i+.34,i+.66],[level,level],linestyle='--',linewidth=1)
    ax.set(xticks=np.arange(6),xticklabels=labels,ylabel='Difference in correct predictions (P90 minus F4)',ylim=(0,8.2),title='From raw +7 to final +2 on 167 common-core claims')
    ax.tick_params(axis='x',labelsize=9);ax.grid(axis='y',linestyle=':',alpha=.3);ax.set_axisbelow(True)
    fig.tight_layout();save(fig,'fig04_p90_transition')

    rr={r['method']:r for r in data['cohorts']['F9065']['rows']}
    delta=np.diag(rr['Text-FT']['cm'])-np.diag(rr['Text-Frozen']['cm'])
    assert delta.tolist()==[311,17,-2]
    fig,ax=plt.subplots(figsize=(8.2,4.8))
    bars=ax.bar(['Supported','Not Supported','Not Addressed'],delta)
    for bar,val in zip(bars,delta):
        ax.text(bar.get_x()+bar.get_width()/2,val+(9 if val>=0 else -9),f'{val:+d}',ha='center',va='bottom' if val>=0 else 'top')
    ax.axhline(0,linewidth=.9)
    ax.set(ylabel='Net additional correct predictions',ylim=(-43,365),title='Text-FT minus Text-Frozen: 9,065 patient-grouped OOF claims')
    ax.text(.97,.94,'Total: +326',transform=ax.transAxes,ha='right')
    ax.grid(axis='y',linestyle=':',alpha=.3);ax.set_axisbelow(True)
    fig.tight_layout();save(fig,'figA1_text_adaptation_gain')
    print('Created four PNG figures and four SVG counterparts in assets/.')

if __name__ == '__main__':
    main()
