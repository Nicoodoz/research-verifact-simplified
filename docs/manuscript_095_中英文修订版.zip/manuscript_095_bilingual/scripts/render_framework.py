"""Render the existing pipeline diagram in Chinese and English.

Requires the graphviz Python package and the Graphviz 'dot' executable.
No inference, network access, or patient data are used. The PNGs bundled with
this package can be displayed without these dependencies.
"""
from pathlib import Path
from graphviz import Digraph
ROOT=Path(__file__).resolve().parents[1]

LABELS={
 'zh': {'H':'合格患者\nEHR', 'X':'原始命题\nx', 'R':'C48混合召回\n与重排',
        'E':'带来源的\n原文证据 E', 'J':'冻结\nT-S Judge',
        'O':'原生标签 r\n自报分数 s\n理由 q', 'F':'Frozen\nPriorG',
        'Y':'原命题\n最终标签', 'A':'同ID类别表现\n错误支持 / 转移分析',
        'GT':'目标病例医生标签\n仅用于评价'},
 'en': {'H':'Eligible patient\nEHR', 'X':'Original\nproposition x', 'R':'C48 hybrid retrieval\nand reranking',
        'E':'Source-attributed\nevidence E', 'J':'Frozen\nT-S judge',
        'O':'Native label r\nSelf-reported scores s\nReason q', 'F':'Frozen\nPriorG',
        'Y':'Final label for the\noriginal proposition', 'A':'Same-ID class performance\nFalse support / transitions',
        'GT':'Target-case clinician label\nEvaluation only'}
}

def main():
 for lang, labels in LABELS.items():
  d=Digraph('framework', engine='dot')
  font='Noto Sans CJK SC' if lang=='zh' else 'DejaVu Sans'
  d.attr(rankdir='LR', ranksep='0.30', nodesep='0.32', pad='0.15', splines='polyline', dpi='180')
  d.attr('node', shape='box', style='rounded', fontname=font, fontsize='14', margin='0.12,0.09', penwidth='1.0')
  d.attr('edge', fontname=font, fontsize='10', arrowsize='0.7', penwidth='1.0')
  for k,l in labels.items():d.node(k,l)
  for a,b in [('H','R'),('X','R'),('R','E'),('E','J'),('X','J'),('J','O'),('F','Y')]:d.edge(a,b)
  d.edge('O','F',label='分数 s' if lang=='zh' else 'scores s')
  for a in ['O','Y','GT']:d.edge(a,'A',style='dashed',label='评价' if lang=='zh' else 'evaluation')
  for format in ['png','svg']:
   target=ROOT/'assets'/f'fig01_framework_{lang}'
   d.render(filename=target.name,directory=target.parent,format=format,cleanup=True)
  (ROOT/'assets'/f'fig01_framework_{lang}.dot').write_text(d.source,encoding='utf-8')
 print('Framework diagrams rendered in zh/en (same nodes and edges).')
if __name__=='__main__':main()
